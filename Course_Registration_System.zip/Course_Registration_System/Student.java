/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Course_Registration_System;
import java.util.ArrayList;
/**
 *
 * @author MEGA
 */
public class Student {

     String department;
     int semester;
     String regNo;
     String name;
    Course[] course=new Course[3];
    
     int courseCount=0;
    
    public Student(String department, String name, String regNo,int semester) 
    {
        this.department=department;
        this.name=name;
        this.regNo=regNo;
        this.semester=semester;
    }
    
    public void registerCourse(Course c)
    {
        for(int i=0;i<=2;i++)
        {
            if(courseCount<3)
            {
            if(i==courseCount)
            {
            course[i]=c;
            courseCount++;
    }
            }
            else
            {
                System.out.println("Courses Array Full");
            }
    }
        
    }
    }



   
