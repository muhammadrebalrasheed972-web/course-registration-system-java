

package Course_Registration_System;

import java.util.Scanner;

/**
 *
 * @author Rebal Rasheed
 */
public class Main {
public static void main(String[] args)
{
    Scanner sc=new Scanner(System.in);
    
    Register reg=new Register();
    int choice;
     while(true)
    {
    System.out.println("\t\t\t\t==============:COurse Registration System:==============");
   
        System.out.println("1.Add New Student");
        System.out.println("2.Add New Course");
        System.out.println("3.Register Course");
        System.out.println("4.Show/Search Registration of Course");
        System.out.println("5.Exit Application");
        System.out.print("\nEnter your choice:");
        choice=sc.nextInt();
        sc.nextLine();
        System.out.println("");
        if(choice==1)
        {
            while(true)
            {
            System.out.println("Enter Details for new student::\n");
            System.out.print("Enter Student Departement :");
            String dept=sc.nextLine();
            System.out.print("Enter Student Name :");
            String name=sc.nextLine();
            System.out.print("Enter Student Reg.No :");
            String regNo=sc.nextLine();
            System.out.print("Enter Student Semester :");
            int sem=sc.nextInt();
            
            System.out.println("");
            
            Student std=new Student(dept,name,regNo,sem);
            reg.addNewStudent(std);
            System.out.println("Student has been added successfully.");
                
                System.out.println("");
                
                 System.out.println("Want to add a new student ?(Then enter 'Yes', anything else will return to main menu.)");
                 System.out.println("Enter choice :");
        String exit=sc.nextLine();
        
                System.out.println("");
                
        if(!exit.equalsIgnoreCase("Yes"))
        {
            break;
}
        }
        
        
    }
        
        else if(choice==2)
        {
            while(true)
            {
            System.out.println("Enter Details for new course::\n");
            System.out.print("Enter Course ID :");
            int id=sc.nextInt();
            sc.nextLine();
            System.out.print("Enter Course Name :");
            String cName=sc.nextLine();
            System.out.print("Enter Course Credits :");
            int credits=sc.nextInt();
            sc.nextLine();
            System.out.print("Enter Course Semester :");
            int cSem=sc.nextInt();
            sc.nextLine();
            
            System.out.println("");
            
            Course course=new Course(id,cName,credits,cSem);
            reg.addNewCourse(course);   
            System.out.println("Student has been added successfully.");
                
                System.out.println("");
                
                 System.out.println("Want to Register a new course ?(Then enter 'Yes', anything else will return to main menu.)");
                 System.out.println("Enter choice :");
        String exit=sc.nextLine();
        
                System.out.println("");
                
        if(!exit.equalsIgnoreCase("Yes"))
        {
            break;
}
        }
        }
        else if(choice==3)
        {
            while(true)
            {
            System.out.println("To Register Course enter these details::\n");
            System.out.print("Enter Reg.No of Student:");
            String regNo=sc.nextLine();
            Student foundStd=null;
           
                for(Student s:reg.student)
                {
                if(s.regNo.equals(regNo))
                {
                    foundStd=s;
                    break;
                }
            }
                if(foundStd==null)
                {
                    System.out.println("\nStudent doesn't exist in Database!");
                }
                else
                {
                
            System.out.print("Enter Course ID:");
            int cId=sc.nextInt();
            sc.nextLine();
            Course foundCrs=null;
           
                for(Course c:reg.course)
                {
                if(c.courseId==cId)
                {
                    foundCrs=c;
                    break;
                }
            }
                if(foundCrs==null)
                {
                    System.out.println("\nCourse doesn't exist in Database!");
                }
                else
                {
                foundStd.registerCourse(foundCrs);
                foundCrs.enrolledStudents.add(foundStd);
                    System.out.println("Course has been registered successfully.");
                }
                System.out.println("");
                }
                 System.out.println("Want to Register a new course ?(Then enter 'Yes', anything else will return to main menu.)");
                 System.out.println("Enter choice :");
        String exit=sc.nextLine();
        
                System.out.println("");
                
        if(!exit.equalsIgnoreCase("Yes"))
        {
            break;
}
    }
    }
        else if(choice==4)
        {
            while(true)
            {
            System.out.print("\nTo Search a course for its details:\nEnter Course ID:");
            int courseSrchId=sc.nextInt();
            Course courseSrch=null;
            for(Course c:reg.course)
            {
                if(c.courseId==courseSrchId)
                {
                    courseSrch=c;
                    courseSrch.courseInfo(courseSrch);
                }
            }
            System.out.println("Student has been added successfully.");
                
                System.out.println("");
                
                 System.out.println("Want to Register a new course ?(Then enter 'Yes', anything else will return to main menu.)");
                 System.out.println("Enter choice :");
        String exit=sc.nextLine();
        
                System.out.println("");
                
        if(!exit.equalsIgnoreCase("Yes"))
        {
            break;
}
        }
            
        }
        else if(choice==5)
        {
            System.out.println("Program Exiting");
            break;
        }
}
}
}
