/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Course_Registration_System;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

/**
 *
 * @author MEGA
 */
public class Course {
     int courseId;
     String courseName;
     int credits;
    int semester;
    
    ArrayList<Student> enrolledStudents=new ArrayList<>();
    
    public Course(int courseId, String courseName, int credits, int semester) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.credits = credits;
        this.semester = semester;
    }
    
    
    void courseInfo(Course c)
    {
        System.out.println("\n\t\t\t=======================Course Information=========================");
        System.out.println("Course name :"+c.courseName);
        System.out.println("Course ID :"+c.courseId);
        System.out.println("Course Credit Hourse :"+c.credits);
        System.out.println("Course Semester :"+c.semester+"\n\n");
        System.out.println("\tREGISTRATION STATUS:::\nStudents registered for this course::\n");
        if(c.enrolledStudents.isEmpty())
        {
            System.out.println("\tREGISTRATION STATUS:::\nNo student has yet registered this course!");
        }
        else
        {
             for(Student courseFinded:c.enrolledStudents)
        {
            System.out.println("Name : "+courseFinded.name+"\tReg.No : "+courseFinded.regNo+"\n");
        }
        }
    }
}


  