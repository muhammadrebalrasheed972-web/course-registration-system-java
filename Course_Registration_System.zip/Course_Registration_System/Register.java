/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Course_Registration_System;
 import java.util.ArrayList;
/**
 *
 * @author MEGA
 */
public class Register {

    ArrayList<Student> student =new ArrayList<>();
    ArrayList<Course> course=new ArrayList<>();
    
 void addNewCourse(Course c)
   {
       course.add(c);
   }
   void addNewStudent(Student std)
   {
       student.add(std);
   }
}

    